from django.urls import re_path as url
from django.urls import path, include
from . import views

urlpatterns = [
    # url(r"^dashboard/", dashboard, name="dashboard"),
    url(r"^accounts/", include("django.contrib.auth.urls")),
    path("dashboard",views.dashboard,name="dashboard"),
    # path("accounts",include("django.contrib.auth.urls"))
]