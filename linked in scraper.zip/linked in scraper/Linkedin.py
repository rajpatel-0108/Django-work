# from urllib import request
from selenium import webdriver 
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver import Chrome
from time import sleep
from bs4 import BeautifulSoup
import csv


driver = webdriver.Chrome("/home/avilash/Avilash work/linked in scraper/chromedriver")
url = "https://www.linkedin.com/uas/login"
driver.get(url)
driver.maximize_window()


username = "kisan.biswal.95@gmail.com" #str(input("Username : "))
password = "Kisan@123" #str(input("Password : "))

sleep(2)

email_field = driver.find_element(By.ID ,'username')
email_field.send_keys(username)
print('- Finish keying in email')
sleep(3)

password_field = driver.find_element(By.NAME , 'session_password')
password_field.send_keys(password)
print('- Finish keying in password')
sleep(2)

signin_field = driver.find_element(By.XPATH , '//*[@id="organic-div"]/form/div[3]/button')
signin_field.click()
sleep(3)

search_field = driver.find_element(By.XPATH , '//*[@id="global-nav-typeahead"]/input')
requirement = str(input("enter your search query : "))
search_field.send_keys(requirement)
sleep(3)
search_field.send_keys(Keys.RETURN)
sleep(5)

searchfieldexpand = driver.find_element(By.LINK_TEXT , 'See all people results') # XPATH - //*[@id="main"]/div/div/div[1]/div[2]/a
sleep(3)
searchfieldexpand.click()

def GetURL():
    page_source = BeautifulSoup(driver.page_source , 'html.parser')
    profiles = page_source.find_all('a', class_ = 'app-aware-link') #('a', class_ = 'search-result__result-link ember-view')
    all_profile_URL = []
    for profile in profiles:
        profile_URL = profile.get('href')
        if profile_URL not in all_profile_URL:
            all_profile_URL.append(profile_URL)
    return all_profile_URL



input_page = int(input('How many pages you want to scrape: '))
URLs_all_page = []
for page in range(input_page):
    URLs_one_page = GetURL()
    sleep(2)
    driver.execute_script('window.scrollTo(0, document.body.scrollHeight);') #scroll to the end of the page
    sleep(3)
    next_button = driver.find_element(By.CLASS_NAME , "artdeco-pagination__button--next")
    driver.execute_script("arguments[0].click();", next_button)
    URLs_all_page = URLs_all_page + URLs_one_page
    sleep(2)


print('URL searching finished')


with open('output.csv', 'w',  newline = '') as file_output:
    headers = ['Name', 'Job Title', 'Location', 'URL']
    writer = csv.DictWriter(file_output, delimiter=',', lineterminator='\n',fieldnames=headers)
    writer.writeheader()
    for linkedin_URL in URLs_all_page:
        driver.get(linkedin_URL)
        print('- Accessing profile: ', linkedin_URL)
        sleep(3)
        page_source = BeautifulSoup(driver.page_source, "html.parser")
        info_div = page_source.find('div',{'class':'mt2 relative'})
        try:
            name = info_div.find('h1', class_='text-heading-xlarge inline t-24 v-align-middle break-words')
            name.get_text().strip() 
            print('--- Profile name is: ', name)
            location = info_div.find('span', class_='text-body-small inline t-black--light break-words')
            location.get_text().strip() 
            print('--- Profile location is: ', location)
            title = info_div.find('div', class_='text-body-medium break-words')
            title.get_text().strip()
            print('--- Profile title is: ', title)
            writer.writerow({headers[0]:name, headers[1]:location, headers[2]:title, headers[3]:linkedin_URL})
            print('\n')
        except Exception as e:
            print(e)

print('Scraping Complete')